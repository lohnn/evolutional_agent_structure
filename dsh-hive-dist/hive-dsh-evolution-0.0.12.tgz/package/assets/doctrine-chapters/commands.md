# HELM Doctrine — Commands reference

dsh commands are user-invoked and gated; they are MODEL-INVISIBLE by
architecture (you can never invoke one — the user does). Know what they do
so you can guide the user to the right one, and relay outcomes.

- `/awaken` — enter this session as the Helmsman at the Helm; re-running it
  runs a gap analysis and changes no state
- `/spawn` — manifest a new capability (the conversation proposes, the user
  approves, the summoned tool executes)
- `/evolve` — self-analysis: gaps, overlaps, decay (with an Audit-grade
  dream sweep); read `hive_doctrine("evolution")` first for the operations
  and the energy table
- `/dissolve` — retire a capability to harbor (archived, resurrectable)
- `/tick` — apply the energy tick by hand (it also auto-fires at most once
  per day at session start)
- `/status` — view the ecosystem: roster, energy, the harbor
- `/dream` — open the dream surface: the dreamtime tools (begin, harvest,
  artifact creation, complete, supersede, mark-stale, detect-duplicates,
  painpoints-harvest) live only during a dream, and `hive_dream_complete`
  sheds them automatically on completion. When you find them absent, ASK THE
  USER to run /dream; /dream is also the manual release (or re-open).

A dormant session sees only the /awaken hint — never half-gated machinery.

<!-- hive:doctrine-chapter:commands v1 -->
